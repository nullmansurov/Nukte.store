import json
import os
import time
from datetime import datetime, timedelta
import pytz

# Обновление active.json
def update_active_json(active_file_path):
    print("Обновление active.json...")
    # Проверка существования файла и его инициализация, если он отсутствует
    if not os.path.exists(active_file_path):
        with open(active_file_path, 'w') as f:
            json.dump([], f)

    try:
        with open(active_file_path, 'r') as f:
            active_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print("Файл пуст или не найден. Создаем новый.")
        active_data = []

    latest_entries = {}
    almaty_tz = pytz.timezone('Asia/Almaty')
    current_time = datetime.now(almaty_tz)

    for entry in active_data:
        post_id = entry['id']
        entry_time = datetime.strptime(entry['time'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=almaty_tz)

        # Сохраняем запись, если её нет в словаре или если текущая запись новее
        if post_id not in latest_entries or entry['time'] > latest_entries[post_id]['time']:
            latest_entries[post_id] = entry

    # Сортируем записи по времени от самой новой к самой старой 
    sorted_entries = sorted(latest_entries.values(), key=lambda x: x['time'], reverse=True)

    # Запись обновленных данных обратно в файл
    with open(active_file_path, 'w') as f:
        json.dump(sorted_entries, f, indent=4)  # Сохраняем с отступами для читабельности

    print("active.json обновлен.")
    return sorted_entries, current_time

# Функция для обновления show в посте
def update_post_show(post_file_path, show_value):
    print(f"Обновление show на {show_value} в посте...")
    with open(post_file_path, 'r', encoding='utf-8') as f:
        post_data = json.load(f)

    # Установка show на новое значение
    post_data['show'] = show_value

    # Запись обновленных данных обратно в файл
    with open(post_file_path, 'w', encoding='utf-8') as f:
        json.dump(post_data, f, ensure_ascii=False, indent=4)

    print(f"show обновлено на {show_value} в посте.")

# Функция для уменьшения connect у пользователя
def update_user_connect(user_file_path, reduce_amount):
    print("Уменьшение connect у пользователя...")
    with open(user_file_path, 'r', encoding='utf-8') as f:
        user_data = json.load(f)

    # Изменяем connect
    user_data['connect'] -= reduce_amount
    print(f"connect уменьшен на {reduce_amount}. Текущий connect: {user_data['connect']}.")

    # Запись обновленных данных обратно в файл
    with open(user_file_path, 'w', encoding='utf-8') as f:
        json.dump(user_data, f, ensure_ascii=False, indent=4)

    return user_data['connect']

def check_and_update_connects_file():
    # Определяем путь к файлу
    file_path = 'C:/Users/Administrator/Desktop/Service/files/users/main/update_connects.json'
    
    # Загружаем данные из файла, если он существует, или инициализируем новый
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    else:
        data = {"isker": None, "iskerpluse": None}

    # Определяем текущее время по Алматы
    almaty_time = datetime.now(pytz.timezone('Asia/Almaty'))
    
    # Проверка и обновление времени для isker (если прошло 7 дней)
    if data['isker']:
        last_update_isker = datetime.fromisoformat(data['isker'])
        if almaty_time - last_update_isker >= timedelta(days=7):
            data['isker'] = almaty_time.isoformat()
    else:
        data['isker'] = almaty_time.isoformat()
    
    # Проверка и обновление времени для iskerpluse (если прошел 1 день)
    if data['iskerpluse']:
        last_update_iskerpluse = datetime.fromisoformat(data['iskerpluse'])
        if almaty_time - last_update_iskerpluse >= timedelta(days=1):
            data['iskerpluse'] = almaty_time.isoformat()
    else:
        data['iskerpluse'] = almaty_time.isoformat()

    # Сохраняем обновленные данные обратно в файл
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def update_connect_values(directory):
    # Обновляем файл update_connects.json перед обходом
    check_and_update_connects_file()
    
    # Проходим по всем файлам в указанной директории
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        
        # Проверяем, является ли файл JSON-файлом
        if os.path.isfile(file_path) and filename.endswith('.json'):
            with open(file_path, 'r', encoding='utf-8') as f:
                user_data = json.load(f)

            # Проверка и обновление connect, если нужно
            if 'connect' in user_data:
                if user_data.get('role') == 'onerpas' and user_data['connect'] < 100:
                    user_data['connect'] = 100  # Обновляем значение до 100
                elif user_data['connect'] < 30:
                    user_data['connect'] = 30  # Обновляем значение до 30

                # Записываем обновленные данные обратно в файл
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(user_data, f, ensure_ascii=False, indent=4)

# Укажите директорию для обновления значений
directory_path = 'C:/Users/Administrator/Desktop/Service/files/users/'

# Основной цикл обновления активных постов
def main():
    active_file_path = 'C:/Users/Administrator/Desktop/Service/files/posts/main/active.json'

    while True:
        print("Запуск обновления активных постов...")
        active_posts, current_time = update_active_json(active_file_path)
        update_connect_values(directory_path)

        for entry in active_posts[:]:  # Создаем копию списка для безопасного удаления
            event_id = entry['id']
            chat_id = entry['chat_id']
            entry_time = datetime.strptime(entry['time'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=pytz.timezone('Asia/Almaty'))

            post_file_path = f'C:/Users/Administrator/Desktop/Service/files/posts/{event_id}.json'
            user_file_path = f'C:/Users/Administrator/Desktop/Service/files/users/{chat_id}.json'

            # Проверка существования файла поста
            if not os.path.exists(post_file_path):
                print(f"Файл поста с ID {event_id} не найден. Удаляем запись из active.json.")
                active_posts.remove(entry)
                with open(active_file_path, 'w') as f:
                    json.dump(active_posts, f, indent=4)
                continue

            connect_count = update_user_connect(user_file_path, 0)
            if connect_count < 1:
                print(f"Пост с chat_id {chat_id} удален, так как количество connect меньше 1.")
                update_post_show(post_file_path, False)
                active_posts.remove(entry)
                with open(active_file_path, 'w') as f:
                    json.dump(active_posts, f, indent=4)
                continue

            if (current_time - entry_time) > timedelta(hours=4):
                print(f"Пост с chat_id {chat_id} будет удален, так как прошло больше 4 часов.")
                connect_count = update_user_connect(user_file_path, 3)
                update_post_show(post_file_path, False)
                active_posts.remove(entry)
                with open(active_file_path, 'w') as f:
                    json.dump(active_posts, f, indent=4)
                continue

        print("Обновления завершены.")
        time.sleep(600)  # Ждем 10 минут перед следующим запуском

# Запускаем основной процесс
if __name__ == "__main__":
    main()
