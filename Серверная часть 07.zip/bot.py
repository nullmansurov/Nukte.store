import os
import json
import telebot
import random
from telebot import types
from datetime import datetime, timedelta
import pytz


# Указываем путь к директории на Google Диске
drive_path = 'C:/Users/Administrator/Desktop/Service/files/'
active_file_path = drive_path + 'posts/main/active.json'

# Проверяем существование папок, если нет - создаем их
if not os.path.exists(drive_path):
    os.makedirs(drive_path)

users_folder = os.path.join(drive_path, 'users')
if not os.path.exists(users_folder):
    os.makedirs(users_folder)

# Путь к файлу userdata.json
main_user_data_file = os.path.join(users_folder, 'main', 'userdata.json')
if not os.path.exists(os.path.join(users_folder, 'main')):
    os.makedirs(os.path.join(users_folder, 'main'))

# Создаем userdata.json, если его нет
if not os.path.exists(main_user_data_file):
    with open(main_user_data_file, 'w', encoding='utf-8') as f:
        json.dump({}, f)

# Указываем ваш токен
TOKEN = '7535790319:AAGkNx36_sn5fDCb30JDczljYNFEfQL0Pa0'
bot = telebot.TeleBot(TOKEN)

# Функция для генерации уникального кода
def generate_code():
    return str(random.randint(1000, 9999))

# Функция для создания нового пользователя
def create_user_file(chat_id, name):
    user_data = {
        "name": name,
        "chat_id": chat_id,
        "connect": 30,
        "code": generate_code(),
        "role": "isker",
        "post": None,
        "ivent": None,
        "activity": "offline"
    }

    user_file = os.path.join(users_folder, f"{chat_id}.json")

    with open(user_file, 'w', encoding='utf-8') as f:
        json.dump(user_data, f)

    return user_file

# Функция для обновления файла userdata.json
def update_main_user_data(chat_id, user_file):
    with open(main_user_data_file, 'r+') as f:
        data = json.load(f)
        data[str(chat_id)] = {
            "user_data": user_file
        }
        f.seek(0)
        json.dump(data, f)
        f.truncate()

# Функция для отправки меню с кнопками
def send_menu(chat_id):
    markup = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    profile_btn = types.KeyboardButton('Профиль')
    change_dir_btn = types.KeyboardButton('Бағытты өзгерту')
    connect_btn = types.KeyboardButton('Коннектер қосу')
    markup.add(profile_btn, change_dir_btn, connect_btn)
    bot.send_message(chat_id, "Әрекетті таңдаңыз:", reply_markup=markup)

# Функция для отображения профиля пользователя
def profile_user(chat_id):
    # Открываем файл userdata.json
    with open(main_user_data_file, 'r', encoding='utf-8') as f:
        registered_users = json.load(f)

    # Проверяем, существует ли пользователь в системе
    if str(chat_id) in registered_users:
        # Загружаем файл пользователя
        user_file = registered_users[str(chat_id)]["user_data"]
        with open(user_file, 'r', encoding='utf-8') as f:
            user_data = json.load(f)

        # Форматируем данные пользователя для отправки
        name = user_data["name"]
        connect = user_data["connect"]
        role = user_data["role"]
        activity = user_data["activity"]

        # Количество коннектов
        if not connect or connect == 0:
            connect_message = "Сізде коннектер жоқ"
        else:
            connect_message = f"Сіздің коннектеріңіз: {connect}"

        # Роль пользователя
        role_names = {
            "ghost": "Қонақ",
            "isker": "Іскер",
            "iskerpluse": "Іскер Плюс",
            "banned": "Бұғатталған"
        }
        role_message = role_names.get(role, "Сіз жүйеге тіркелмегенсіз!")

        # Активность
        activity_message = "Онлайн" if activity == "online" else "Оффлайн"

        # Сообщение с профилем пользователя
        profile_message = (
            f"👤 Есіміңіз: {name}\n"
            f"🔗 {connect_message}\n"
            f"🛡 Лауазымыңыз: {role_message}\n"
        )
        bot.send_message(chat_id, profile_message)

        # Клавиатура с кнопками после профиля
        markup = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)

        # Кнопки для роли "user"
        if role in ["isker", "iskerpluse"]:
            view_posts_btn = types.KeyboardButton('Менің жарнамаларым')
            add_post_btn = types.KeyboardButton('Жарнама қосу')
            post_btn = types.KeyboardButton('Коннектерді толтыру')
            markup.add(view_posts_btn, add_post_btn, post_btn)

        if role == "ghost":
            post_btn2 = types.KeyboardButton('Мен іскермін')
            markup.add(post_btn2)

        if role == "banned":
            bot.send_message(chat_id, "Сіздің аккаунтыңыз бұғатталған, сізге рұқсат жоқ", reply_markup=types.ReplyKeyboardRemove())

        if role in ["ghost", "isker", "iskerpluse"]:
            profile = types.KeyboardButton('Профиль')
            markup.add(profile)        

        bot.send_message(chat_id, "Әрекетті таңдаңыз:", reply_markup=markup)

# Состояния для пользователя
user_states = {}

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start_message(message):
    chat_id = message.chat.id

    # Открываем userdata.json для проверки, зарегистрирован ли пользователь
    with open(main_user_data_file, 'r', encoding='utf-8') as f:
        registered_users = json.load(f)

    # Если пользователя нет в файле userdata.json, запрашиваем его имя
    if str(chat_id) not in registered_users:
        bot.reply_to(message, "Сәлеметсіз бе? Атыңыз кім?")
        user_states[chat_id] = 'waiting_for_name'
    else:
        # Если пользователь уже зарегистрирован, отправляем профиль
        profile_user(chat_id)

# Обработчик для регистрации пользователя
@bot.message_handler(func=lambda message: message.chat.id in user_states and user_states[message.chat.id] == 'waiting_for_name')
def handle_registration_name(message):
    chat_id = message.chat.id
    name = message.text

    # Создаем файл пользователя
    user_file = create_user_file(chat_id, name)
    # Обновляем userdata.json
    update_main_user_data(chat_id, user_file)

    # Удаляем состояние
    user_states.pop(chat_id)

    bot.reply_to(message, f"Қош келдіңіз, {name}! Сіз жүйеге тіркелдіңіз.")
    # Отправляем профиль пользователя
    profile_user(chat_id)


def get_user_id(chat_id):
    userconnectfile = f'C:/Users/Administrator/Desktop/Service/files/users/{chat_id}.json'
    
    # Загружаем данные пользователя
    with open(userconnectfile, 'r', encoding='utf-8') as f:
        user_data = json.load(f)
    
    # Уменьшаем connect на 1
    role = user_data['role']
    return role

# ---------------------------------------------------------------------------------------------------- Меню
# Обработчик для нажатия кнопки "Профиль"
@bot.message_handler(func=lambda message: message.text == 'Профиль')
def handle_profile(message):
    chat_id = message.chat.id
    profile_user(chat_id)

# Обработчик для нажатия кнопки "Менің жарнамаларым"
@bot.message_handler(func=lambda message: message.text == 'Менің жарнамаларым')
def handle_view_posts(message):
    chat_id = message.chat.id
    role = get_user_id(chat_id)
    if role == "ghost":
        bot.send_message(chat_id, "Сіз жүйеге тіркелмегенсіз, алдымен /start пәрменін басыңыз")
    elif role == 'banned':
        bot.send_message(chat_id, "Сіздің аккаунтыңыз бұғатталған, сізге рұқсат жоқ")
    elif role in ['isker', 'iskerpluse']:
        display_user_posts(chat_id)
    else:
        bot.send_message(chat_id, "Алдымен жүйеге тіркеліңіз")

# Обработчик для нажатия кнопки "Жарнама қосу"
@bot.message_handler(func=lambda message: message.text == 'Жарнама қосу')
def handle_add_post(message):
    chat_id = message.chat.id
    role = get_user_id(chat_id)
    if role == "ghost":
        bot.send_message(chat_id, "Сіз жүйеге тіркелмегенсіз, алдымен /start пәрменін басыңыз")
    elif role == 'banned':
        bot.send_message(chat_id, "Сіздің аккаунтыңыз бұғатталған, сізге рұқсат жоқ")
    elif role in ['isker', 'iskerpluse']:
        create_post(chat_id)
    else:
        bot.send_message(chat_id, "Алдымен жүйеге тіркеліңіз")


# Обработчик для нажатия кнопки "Мен іскермін"
@bot.message_handler(func=lambda message: message.text == 'Мен іскермін')
def handle_request(message):
    chat_id = message.chat.id
    role = get_user_id(chat_id)
    if role == "ghost":
        new_user(chat_id)
    else:
        bot.send_message(chat_id, 'Сіз бұл пәрменді қолдана алмайсыз')

# Обработчик для нажатия кнопки "Коннектерді толтыру"
@bot.message_handler(func=lambda message: message.text == 'Коннектерді толтыру')
def handle_connects(message):
    chat_id = message.chat.id
    role = get_user_id(chat_id)
    if role in ['ghost', 'isker', 'iskerpluse']:
        connect_buy(chat_id)
    else:
        bot.send_message(chat_id, 'Сіз бұл пәрменді қолдана алмайсыз')


#-------------------------------------------------------- Админ панелі
admin_chat_id = -4546293111

users_folder = "C:/Users/Administrator/Desktop/Service/files/users/"
posts_directory = "C:/Users/Administrator/Desktop/Service/files/posts/"

# Функция для обработки команды /search
def search_step1(message):
    if message.chat.id == admin_chat_id:
        # Запрашиваем поисковой запрос
        bot.send_message(admin_chat_id, "Қандай кілтсөздермен жарнамаларды іздейміз?:")
        bot.register_next_step_handler(message, perform_search)
    else:
        bot.send_message(message.chat.id, "Сізде бұл пәрменге рұқсат жоқ")

from telebot import types

# Функция для отображения найденных постов с информацией о создателе для админа
def display_admin_posts(post_ids, page=1):
    if not post_ids:
        bot.send_message(admin_chat_id, "Сіздің кілтсөздеріңіз бойынша жарнамалар табылмады.")
        return

    posts_per_page = 5
    total_posts = len(post_ids)
    total_pages = (total_posts + posts_per_page - 1) // posts_per_page

    start = (page - 1) * posts_per_page
    end = start + posts_per_page
    current_page_posts = post_ids[start:end]

    for post_id in current_page_posts:
        post_file_path = os.path.join(posts_directory, f"{post_id}.json")

        if os.path.exists(post_file_path):
            with open(post_file_path, 'r', encoding='utf-8') as post_file:
                post_data = json.load(post_file)

            # Ищем пользователя, связанного с этим постом
            user_chat_id = find_user_by_post_id(post_id)
            user_name = "Қолданушы" if user_chat_id is None else f"chat_id: {user_chat_id}"

            availability = "Ашық" if post_data.get('show', False) else "Жабық"
            url_text = post_data.get('url', "Көрсетілмеген")
            message_text = (
                f"Тақырып: {post_data.get('title', 'Жоқ')}\n"
                f"Елді мекен: {post_data.get('where', 'Көрсетілмеген')}\n"
                f"Сипаттамасы: {post_data.get('description', 'Жоқ')}\n"
                f"Бағытты: {post_data.get('tags', 'Таңдалмаған')}\n"
                f"Байланыс сілтемесі: {url_text}\n"
                f"Қолжетімділік: {availability}\n"
                f"Жарнаманың авторы: {user_name}\n"
            )

            media = []
            if post_data.get('photo'):
                unique_photos = list(set(post_data['photo']))
                for photo_path in unique_photos:
                    if os.path.exists(photo_path):
                        media.append(types.InputMediaPhoto(media=open(photo_path, 'rb')))

            # Отправляем фотографии группами по 10
            while media:
                group_media = media[:10]
                media = media[10:]
                bot.send_media_group(admin_chat_id, group_media)

            # Кнопки управления постом
            markup = types.InlineKeyboardMarkup()
            delete_button = types.InlineKeyboardButton("Өшіру", callback_data=f"delete_{post_id}_{user_chat_id}")  # Передаем user_chat_id
            markup.add(delete_button)

            bot.send_message(admin_chat_id, message_text, reply_markup=markup)
        else:
            bot.send_message(admin_chat_id, f"Жарнама {post_id} табылмады")

    # Добавляем навигационные кнопки
    nav_markup = types.InlineKeyboardMarkup()
    if page > 1:
        prev_button = types.InlineKeyboardButton("Алдыңғы бет", callback_data=f"admin_page_{page - 1}")
        nav_markup.add(prev_button)
    if page < total_pages:
        next_button = types.InlineKeyboardButton("Келесі бет", callback_data=f"admin_page_{page + 1}")
        nav_markup.add(next_button)

    # Отправляем сообщение с навигацией, если страниц больше одной
    if total_pages > 1:
        bot.send_message(admin_chat_id, f"Парақ саны {page}/{total_pages}", reply_markup=nav_markup)

# Функция для обработки нажатия кнопок управления постами
@bot.callback_query_handler(func=lambda call: call.data.startswith("delete_") or call.data.startswith("action_"))
def handle_post_management(call):
    data = call.data.split("_")
    action = data[0]  # 'delete' или 'toggle'
    post_id = int(data[1])
    user_chat_id = int(data[2])  # Получаем chat_id создателя

    if action == "delete":
        delete_post(post_id, user_chat_id)
    elif action == "action":
        toggle_post_visibility(post_id, user_chat_id)

# Функция для удаления поста
def delete_post(post_id, user_chat_id):
    post_file_path = os.path.join(posts_directory, f"{post_id}.json")

    if os.path.exists(post_file_path):
        os.remove(post_file_path)
        bot.send_message(admin_chat_id, f"Жарнама {post_id} өшірілді.")
    else:
        bot.send_message(admin_chat_id, f"Жарнама {post_id} табылмады")

# Добавляем вызов display_admin_posts после выполнения поиска
def perform_search(message):
    search_query = message.text.strip()
    post_ids = []

    for filename in os.listdir(posts_directory):
        if filename.endswith(".json"):
            file_path = os.path.join(posts_directory, filename)
            with open(file_path, 'r', encoding='utf-8') as file:
                post_data = json.load(file)

            title = post_data.get("title", "") or ""
            description = post_data.get("description", "") or ""
            text_data = title + " " + description

            if search_query.lower() in text_data.lower():
                post_ids.append(post_data['id'])

    if post_ids:
        display_admin_posts(post_ids, page=1)  # Выводим найденные посты
    else:
        bot.send_message(admin_chat_id, "Сіздің сұранысыңыз бойынша ештеңе табылмады")


def find_user_by_post_id(post_id):
    for filename in os.listdir(users_folder):
        if filename.endswith(".json"):
            user_file_path = os.path.join(users_folder, filename)
            with open(user_file_path, 'r', encoding='utf-8') as user_file:
                user_data = json.load(user_file)

            # Проверяем, что поле "post" существует и является списком перед проверкой поста
            user_posts = user_data.get("post", [])
            if user_posts is not None and post_id in user_posts:
                return user_data.get("chat_id")  # Возвращаем chat_id пользователя
    return None  # Если не нашли, возвращаем None


# Команда /search для запуска поиска
@bot.message_handler(commands=["search"])
def search_command_handler(message):
    search_step1(message)

def new_user(chat_id):
    markup = types.InlineKeyboardMarkup()
    # Заменяем кнопку на ссылку
    skip_button = types.InlineKeyboardButton("Тіркелу бөлмесіне өту", url="https://t.me/nuktebirzha/2")
    markup.add(skip_button)

    admin_chat_id = -4546293111
    bot.send_message(chat_id, "Біздің платформада іс-бастау үшін, алдымен қарапайым тексерістен өту қажет", reply_markup=markup)

    # Открываем файл userdata.json
    with open(main_user_data_file, 'r', encoding='utf-8') as f:
        registered_users = json.load(f)

    # Проверяем, существует ли пользователь в системе
    if str(chat_id) in registered_users:
        # Загружаем файл пользователя
        user_file = registered_users[str(chat_id)]["user_data"]
        with open(user_file, 'r', encoding='utf-8') as f:
            user_data = json.load(f)

        # Форматируем данные пользователя для отправки
        name = user_data["name"]
        bot.send_message(admin_chat_id, f"Қолданушы іскерлікке өтініш тастады:\nЕсімі: {name}\nОның chat_id: {chat_id}")

def connect_buy(chat_id):
    admin_chat_id = -4546293111
    role = get_user_id(chat_id)
    if role == "isker":
        markup = types.InlineKeyboardMarkup()
        skip_button = types.InlineKeyboardButton("Өтініш тастау", url="https://t.me/nullmansurov")
        markup.add(skip_button)

        bot.send_message(chat_id, "Іскер лауазымындағы қолданушыларға, аптасайын 30 коннектке дейін толтырылады. Сіздің коннектеріңіз сенбі күні беріледі, күте тұрыңыз")
        bot.send_message(chat_id, "Немесі Іскер Плюс лауазымына өтініш тастаңыз", reply_markup=markup)
    elif role == "iskerpluse":
        markup = types.InlineKeyboardMarkup()
        skipp_button = types.InlineKeyboardButton("Админге жазу", url="https://t.me/nullmansurov")
        markup.add(skipp_button)

        bot.send_message(chat_id, "Іскер Плюс лауазымындағы қолданушыларға, күнсайын 100 коннектке дейін толтырылады")
        bot.send_message(chat_id, "Ертеңге дейін күте тұрыңыз, немесе админге жазыңыз", reply_markup=markup)
        
    # Открываем файл userdata.json
    with open(main_user_data_file, 'r', encoding='utf-8') as f:
        registered_users = json.load(f)

    # Проверяем, существует ли пользователь в системе
    if str(chat_id) in registered_users:
        # Загружаем файл пользователя
        user_file = registered_users[str(chat_id)]["user_data"]
        with open(user_file, 'r', encoding='utf-8') as f:
            user_data = json.load(f)

        # Форматируем данные пользователя для отправки
        name = user_data["name"]
        bot.send_message(admin_chat_id, f"Қолданушы коннектерді толтыруға өтініш тастады:\nЕсімі: {name}\nОның chat_id: {chat_id}")


# Функция для изменения роли пользователя
def change_user_role_step1(message):
    if message.chat.id == admin_chat_id:
        # Запрашиваем chat_id пользователя
        bot.send_message(admin_chat_id, "Қолданушының лауазымен өзгерту үшін, оның chat_id енгізіңіз:")
        bot.register_next_step_handler(message, get_user_file)
    else:
        bot.send_message(message.chat.id, "Сізде бұл пәрменге рұқсат жоқ")

# Получаем файл пользователя и показываем кнопки для изменения роли
def get_user_file(message):
    chat_id_to_change = message.text.strip()
    user_file = os.path.join(users_folder, f"{chat_id_to_change}.json")

    if os.path.exists(user_file):
        markup = types.InlineKeyboardMarkup()
        user_button = types.InlineKeyboardButton("Іскер", callback_data=f"set_role_isker_{chat_id_to_change}")
        iskerpluse_button = types.InlineKeyboardButton("Іскер +", callback_data=f"set_role_iskerpluse_{chat_id_to_change}")
        banned_button = types.InlineKeyboardButton("Бан беру", callback_data=f"set_role_banned_{chat_id_to_change}")
        markup.add(user_button, iskerpluse_button, banned_button)

        bot.send_message(admin_chat_id, "Қолданушының жаңа лауазымын таңдаңыз:", reply_markup=markup)
    else:
        bot.send_message(admin_chat_id, "Бұндай қолданушы табылмады, басынан бастаңыз")

# Обработка нажатия на кнопку
@bot.callback_query_handler(func=lambda call: call.data.startswith("set_role_"))
def callback_change_role(call):
    data = call.data.split("_")
    new_role = data[2]  # user или iskerpluse
    chat_id_to_change = data[3]
    user_file = os.path.join(users_folder, f"{chat_id_to_change}.json")

    if os.path.exists(user_file):
        with open(user_file, 'r', encoding='utf-8') as f:
            user_data = json.load(f)

        # Изменяем роль пользователя
        user_data["role"] = new_role

        # Сохраняем изменения
        with open(user_file, 'w', encoding='utf-8') as f:
            json.dump(user_data, f)

        bot.send_message(admin_chat_id, f"Қолданушының мына chat_id бойынша {chat_id_to_change}, лауазымы ауысты {new_role}.")
    else:
        bot.send_message(admin_chat_id, "Бұндай қолданушы тіркелмеген")

# Использование команды /role для запуска изменения роли
@bot.message_handler(commands=["role"])
def role_command_handler(message):
    change_user_role_step1(message)

# Функция для обработки команды /get_connects
def get_connects_step1(message):
    if message.chat.id == admin_chat_id:
        # Запрашиваем chat_id пользователя
        bot.send_message(admin_chat_id, "Қолданушығы коннектер қосу үшін, онай chat_id енгіңіз:")
        bot.register_next_step_handler(message, get_connect_count)
    else:
        bot.send_message(message.chat.id, "Сізде бұл пәрменге рұқсат жоқ")

# Получаем количество коннектов для добавления
def get_connect_count(message):
    chat_id_to_change = message.text.strip()
    user_file = os.path.join(users_folder, f"{chat_id_to_change}.json")

    if os.path.exists(user_file):
        # Сохраняем chat_id и переходим к запросу количества коннектов
        bot.send_message(admin_chat_id, "Қанша коннектер қосамыз? (Егер -1 болса, онда 1 коннект қолданушыдан алынады):")
        bot.register_next_step_handler(message, add_connects, chat_id_to_change)
    else:
        bot.send_message(admin_chat_id, "Қолданушы табылмады, басынан бастаңыз.")

# Добавляем коннекты пользователю
def add_connects(message, chat_id_to_change):
    try:
        connect_count = int(message.text.strip())
    except ValueError:
        bot.send_message(admin_chat_id, "Тек қана сандар жаза аласыз, басынан бастаңыз.")
        return

    user_file = os.path.join(users_folder, f"{chat_id_to_change}.json")

    with open(user_file, 'r', encoding='utf-8') as f:
        user_data = json.load(f)

    # Проверяем, есть ли поле "connect" и добавляем к нему количество коннектов
    if "connect" in user_data and isinstance(user_data["connect"], int):
        user_data["connect"] += connect_count
    else:
        # Если поле отсутствует или некорректно, устанавливаем начальное значение
        user_data["connect"] = connect_count

    # Сохраняем изменения
    with open(user_file, 'w', encoding='utf-8') as f:
        json.dump(user_data, f)

    bot.send_message(admin_chat_id, f"Қолданушы {chat_id_to_change} коннтектер саны {connect_count} өзгертілді. Енді оның {user_data['connect']} коннектері бар.")

# Команда /get_connects для запуска процесса добавления коннектов
@bot.message_handler(commands=["get_connects"])
def get_connects_command_handler(message):
    get_connects_step1(message)

# Функция для обработки команды /send_message
def send_message_step1(message):
    if message.chat.id == admin_chat_id:
        # Қолданушыға хабарлама жіберу үшін chat_id сұраймыз
        bot.send_message(admin_chat_id, "Хабарлама жіберу үшін қолданушының chat_id енгізіңіз:")
        bot.register_next_step_handler(message, get_user_chat_id)
    else:
        bot.send_message(message.chat.id, "Сізде бұл пәрменге рұқсат жоқ.")

# Қолданушының chat_id аламыз және хабарламаны сұраймыз
def get_user_chat_id(message):
    chat_id_to_send = message.text.strip()
    
    # chat_id тек сандардан тұратынын тексереміз
    if chat_id_to_send.isdigit():
        bot.send_message(admin_chat_id, "Жіберетін хабарламаны енгізіңіз:")
        bot.register_next_step_handler(message, send_message_to_user, chat_id_to_send)
    else:
        bot.send_message(admin_chat_id, "Қате chat_id, қайтадан енгізіңіз.")
        send_message_step1(message)

# Қолданушыға хабарлама жібереміз
def send_message_to_user(message, chat_id_to_send):
    text_to_send = message.text.strip()
    
    try:
        bot.send_message(chat_id_to_send, text_to_send)
        bot.send_message(admin_chat_id, f"{chat_id_to_send} қолданушысына хабарлама жіберілді.")
    except Exception as e:
        bot.send_message(admin_chat_id, f"Хабарлама жіберу қатесі: {e}")

# /send_message пәрмені арқылы қолданушыға хабарлама жіберу
@bot.message_handler(commands=["send_message"])
def send_message_command_handler(message):
    send_message_step1(message)

# ---------------------- Жарнама жасау бөлімі
import uuid

# Функция для получения уникального ID для фотографий
def get_next_photo_id():
    return str(uuid.uuid4())  # Генерируем уникальный ID в формате UUID

user_post_states = {}

# Укажите путь к директории на вашем Google Drive
posts_folder = 'C:/Users/Administrator/Desktop/Service/files/posts'
photos_folder = 'C:/Users/Administrator/Desktop/Service/files/posts/photo'

# Убедитесь, что папка для фотографий существует
os.makedirs(photos_folder, exist_ok=True)

# Функция для получения следующего уникального ID для поста
def get_next_post_id():
    post_ids = [int(file.split('.')[0]) for file in os.listdir(posts_folder) if file.endswith('.json')]
    if post_ids:
        return max(post_ids) + 1  # Возвращаем следующий ID
    else:
        return 0  # Если нет постов, начинаем с 0

# Функция для создания поста
def create_post(chat_id):
    post_id = get_next_post_id()
    # Создаем новый пост с базовыми данными
    new_post = {
        "id": post_id,
        "where": None,
        "title": None,
        "description": None,
        "tags": None,
        "photo": [],
        "url": None,
        "show": False
    }

    # Сохраняем пост в временное состояние для пользователя
    user_post_states[chat_id] = {
        "state": "waiting_for_title",  # Стартуем с запроса заголовка
        "post_data": new_post,
        "photos": []  # Для хранения прикрепленных фото
    }

    # Отправляем сообщение с запросом заголовка поста
    bot.send_message(chat_id, f"Жарнаманың тақырыбын жазыңыз:", reply_markup=types.ReplyKeyboardRemove())

# Обработчик для этапов добавления поста
@bot.message_handler(func=lambda message: message.chat.id in user_post_states)
def handle_post_creation(message):
    chat_id = message.chat.id
    post_state = user_post_states[chat_id]
    current_state = post_state['state']
    post_data = post_state['post_data']

    # Обработка заголовка
    if current_state == 'waiting_for_title':
        post_data['title'] = message.text
        post_state['state'] = 'waiting_for_location'
        markup = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
        markup.add('Шардара', 'Жаушықұм', 'Қуандық', 'Ақберді', 'Қуандық', 'Шардара ауылы', 'Қоссейіт', 'Көксу', 'Басланды', 'Қуандық', 'Ұзыната', 'Жоласар', 'Алатау батыр', 'Қызылқұм', 'Ақалтын',  'Достық')
        bot.send_message(chat_id, "Елдімекенді таңдаңыз:", reply_markup=markup)

    # Обработка местоположения
    elif current_state == 'waiting_for_location':
        if message.text in ['Шардара', 'Жаушықұм', 'Қуандық', 'Ақберді', 'Қуандық', 'Шардара ауылы', 'Қоссейіт', 'Көксу', 'Басланды', 'Қуандық', 'Ұзыната', 'Жоласар', 'Алатау батыр', 'Қызылқұм', 'Ақалтын',  'Достық']:
            post_data['where'] = message.text
            post_state['state'] = 'waiting_for_tags'
            # Кнопки с тематиками
            markup = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
            markup.add('Логистика', 'Такси', 'Көлік', 'Жалға алу/беру', 'Ауыл-шаруашылығы', 'Мал-шаруашылығы', 'Құрылыс', 'Жылжымайтын мүлік', 'Азық-түлік', 'Вакансия', 'Қызыметтер', 'Интернет және Электроника', 'Іс-шаралар', 'Мәдиниет', 'Көңіл-сауық кештері', 'Музыка', 'Денсаулық', 'Киім кешек', 'Жиһаздар', 'Үй-техника', 'Басқалары')
            bot.send_message(chat_id, "Жарнаманың тақырыбын таңдаңыз:", reply_markup=markup)
        else:
            bot.send_message(chat_id, "Тек төменде ұсынылған елді-мекенді таңдаңай аласыз")

    # Обработка тегов
    elif current_state == 'waiting_for_tags':
        if message.text in ['Логистика', 'Такси', 'Көлік', 'Жалға алу/беру', 'Ауыл-шаруашылығы', 'Мал-шаруашылығы', 'Құрылыс', 'Жылжымайтын мүлік', 'Азық-түлік', 'Вакансия', 'Қызыметтер', 'Интернет және Электроника', 'Іс-шаралар', 'Мәдиниет', 'Көңіл-сауық кештері', 'Музыка', 'Денсаулық', 'Киім кешек', 'Жиһаздар', 'Үй-техника', 'Басқалары']:
            post_data['tags'] = message.text
            post_state['state'] = 'waiting_for_description'
            bot.send_message(chat_id, "Жарнаманың сипаттамасын енгізңіз:", reply_markup=types.ReplyKeyboardRemove())
        else:
            bot.send_message(chat_id, "Тек төменде ұсынылған тақырыптарды таңдаңай аласыз")

    # Обработка описания
    elif current_state == 'waiting_for_description':
        if len(message.text.split()) <= 1200:
            post_data['description'] = message.text
            post_state['state'] = 'waiting_for_messenger'  # Изменяем состояние на 'waiting_for_messenger'
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            whatsapp_button = types.KeyboardButton("Whatsapp")
            telegram_button = types.KeyboardButton("Telegram")
            markup.add(whatsapp_button, telegram_button)
            bot.send_message(chat_id, "Қай мессенджер арқылы хабарласқанын қалайсыз?", reply_markup=markup)
        else:
            bot.send_message(chat_id, "Тым ұзақ сипаттама. Тек 1200 сөзге дейін тұратын сипттаманы қабылдаймыз.")

    # Обработка выбора мессенджера
    elif current_state == 'waiting_for_messenger':
        if message.text == "Whatsapp":
            post_data['messenger'] = "whatsapp"
            bot.send_message(chat_id, "Номеріңізді енгізіңіз (+ ті жазудың қажеті жоқ, мысалыға 77714568517):", reply_markup=types.ReplyKeyboardRemove())
            post_state['state'] = 'waiting_for_phone_number'
        elif message.text == "Telegram":
            post_data['messenger'] = "telegram"
            bot.send_message(chat_id, "Номеріңізді немесе юзернеймізді енгізіңіз (+ ті енгізіңіз, мысалыға +77714568517, юзернейм енгізерде @ қолданбаңыз, мысалыға nullmansurov):", reply_markup=types.ReplyKeyboardRemove())
            post_state['state'] = 'waiting_for_phone_number'
        else:
            bot.send_message(chat_id, "Whatsapp немесе Telegram таңдаңыз.")

    # Обработка номера телефона
    elif current_state == 'waiting_for_phone_number':
        phone_number = message.text
        if post_data.get('messenger') == "whatsapp":
            post_data['url'] = f"wa.me/{phone_number}"
        elif post_data.get('messenger') == "telegram":
            post_data['url'] = f"t.me/{phone_number}"
        
        post_state['state'] = 'waiting_for_photo'
        markup = types.InlineKeyboardMarkup()
        skip_button = types.InlineKeyboardButton("Өткізіп жіберу", callback_data="skip_photos")
        markup.add(skip_button)
        bot.send_message(chat_id, "Енді жарнамға суреттер қоса аласыз, немесе 'Өткізіп жіберу' батырмасын басыңыз", reply_markup=markup)
        

@bot.callback_query_handler(func=lambda call: call.data == "skip_photos")
def handle_skip_photos(call):
    chat_id = call.message.chat.id
    post_state = user_post_states[chat_id]

    post_state['state'] = 'completed'  # Устанавливаем состояние завершенным
    finish_post_creation(chat_id)  # Завершаем создание поста
    bot.answer_callback_query(call.id)  # Подтверждаем нажатие кнопки

@bot.message_handler(content_types=['photo'], func=lambda message: message.chat.id in user_post_states)
def handle_photos(message):
    chat_id = message.chat.id
    post_state = user_post_states[chat_id]
    post_data = post_state['post_data']

    # Обработка фотографий
    photo_id = get_next_photo_id()  # Генерируем уникальный ID для фото
    file_id = message.photo[-1].file_id  # Получаем ID фото
    photo_file = bot.get_file(file_id)  # Получаем объект файла
    photo_path = os.path.join(photos_folder, f"{photo_id}.jpg")  # Путь для сохранения фото
    downloaded_photo = bot.download_file(photo_file.file_path)  # Загружаем фото

    with open(photo_path, 'wb') as photo_f:
        photo_f.write(downloaded_photo)  # Сохраняем фото
    post_state['photos'].append(photo_path)  # Добавляем фото в состояние
    print(f"Фотография сохранена: {photo_path}")  # Отладочное сообщение

    if len(post_state['photos']) < 3:
        markup = types.InlineKeyboardMarkup()
        skip_button = types.InlineKeyboardButton("Өткізіп жіберу", callback_data="skip_photos")
        markup.add(skip_button)
        bot.send_message(chat_id, f"Кесін қосылды! Тағыда {3 - len(post_state['photos'])} сурет қоса аласыз, немесе 'Өткізіп жіберу' батырмасын басыңыз.", reply_markup=markup)
    else:
        post_state['state'] = 'completed'
        finish_post_creation(chat_id)


def reduce_user_connect_by_one(chat_id):
    userconnectfile = f'C:/Users/Administrator/Desktop/Service/files/users/{chat_id}.json'
    
    # Загружаем данные пользователя
    with open(userconnectfile, 'r', encoding='utf-8') as f:
        user_data = json.load(f)
    
    # Уменьшаем connect на 1
    user_data['connect'] -= 1

    # Записываем обновленные данные обратно в файл
    with open(userconnectfile, 'w', encoding='utf-8') as f:
        json.dump(user_data, f, ensure_ascii=False, indent=4)

def finish_post_creation(chat_id):
    post_state = user_post_states.pop(chat_id, None)  # Удаляем временные данные
    if post_state is None:
        bot.send_message(chat_id, "Қателік орын алды")
        return

    post_data = post_state['post_data']
    post_data['photo'] = post_state['photos']

    post_file = os.path.join(posts_folder, f"{post_data['id']}.json")
    with open(post_file, 'w', encoding='utf-8') as f:
        json.dump(post_data, f)

    user_file_path = os.path.join(users_folder, 'main', 'userdata.json')
    with open(user_file_path, 'r', encoding='utf-8') as user_file:
        user_data = json.load(user_file)

    # Получаем данные пользователя
    user_info = user_data.get(str(chat_id), {})
    if not user_info:
        bot.send_message(chat_id, "Сіз қолданушы емессіз")
        return

    user_file_path = user_info["user_data"]

    with open(user_file_path, 'r', encoding='utf-8') as user_file:
        user_data = json.load(user_file)

    # Добавляем ID ивента в поле 'post'
    if user_data.get('post') is None:
        user_data['post'] = []
    user_data['post'].append(post_data['id'])

    with open(user_file_path, 'w', encoding='utf-8') as user_file:
        json.dump(user_data, user_file)

    reduce_user_connect_by_one(chat_id)    
    profile_user(chat_id)
    bot.send_message(chat_id, "Сіздің жарнамаңыз сәтті сақталды!")


# --------------------------------------------------- Редактировать посты

from datetime import datetime, timedelta

# Путь к директории с данными пользователей
users_folder = 'C:/Users/Administrator/Desktop/Service/files/users'

# Функция для отображения постов пользователя с пагинацией
def display_user_posts(chat_id, page=1):
    user_file_path = os.path.join(users_folder, f"{chat_id}.json")

    # Проверяем, существует ли файл пользователя
    if not os.path.exists(user_file_path):
        bot.send_message(chat_id, "Сіз жүйеге тіркелмегенсіз.")
        return

    # Считываем данные пользователя
    with open(user_file_path, 'r', encoding='utf-8') as user_file:
        user_data = json.load(user_file)

    # Сортируем посты по ID в порядке убывания
    user_posts = sorted(user_data.get('post', []), reverse=True)
    if not user_posts:
        bot.send_message(chat_id, "Сізде жарнамалар жоқ")
        return

    # Устанавливаем количество постов на странице
    posts_per_page = 5
    total_posts = len(user_posts)
    total_pages = (total_posts + posts_per_page - 1) // posts_per_page  # Всего страниц

    # Получаем посты для текущей страницы
    start = (page - 1) * posts_per_page
    end = start + posts_per_page
    current_page_posts = user_posts[start:end]

    for post_id in current_page_posts:
        post_file_path = os.path.join(posts_folder, f"{post_id}.json")
        if os.path.exists(post_file_path):
            with open(post_file_path, 'r', encoding='utf-8') as post_file:
                post_data = json.load(post_file)

            # Формируем текст сообщения с данными поста
            availability = "Ашық" if post_data['show'] else "Жабық"
            url_text = post_data['url'] if post_data['url'] else "Көрсетілмеген"
            message_text = (
                f"Тақырыбы: {post_data['title']}\n"
                f"Елді-мекен: {post_data['where']}\n"
                f"Сипаттамасы: {post_data['description']}\n"
                f"Бағыты: {post_data['tags']}\n"
                f"Кері-байланыс сілтемесі: {url_text}\n"
                f"Қолжетімділігі: {availability}\n"
            )

            media = []
            if post_data['photo']:
                unique_photos = list(set(post_data['photo']))

                for photo_path in unique_photos:
                    if os.path.exists(photo_path):
                        media.append(types.InputMediaPhoto(media=open(photo_path, 'rb')))

            # Отправляем фотографии группами по 10
            while media:
                group_media = media[:10]
                media = media[10:]
                bot.send_media_group(chat_id, group_media)

            # Отправляем сообщение с данными поста и кнопками
            markup = types.InlineKeyboardMarkup()
            delete_button = types.InlineKeyboardButton("Өшіру", callback_data=f"delpost_{post_id}")
            toggle_button = types.InlineKeyboardButton("Қолжетімділікті өзгерту", callback_data=f"toggle_{post_id}")
            markup.add(delete_button, toggle_button)

            bot.send_message(chat_id, message_text, reply_markup=markup)
        else:
            bot.send_message(chat_id, f"Бұл жарнама жойылып кеткен!")

    # Добавляем навигационные кнопки
    nav_markup = types.InlineKeyboardMarkup()
    if page > 1:
        prev_button = types.InlineKeyboardButton("Алдыңғы бет", callback_data=f"page_{page - 1}")
        nav_markup.add(prev_button)
    if page < total_pages:
        next_button = types.InlineKeyboardButton("Келесі бет", callback_data=f"page_{page + 1}")
        nav_markup.add(next_button)

    # Отправляем сообщение с навигационными кнопками, если есть больше одной страницы
    if total_pages > 1:
        bot.send_message(chat_id, f"Бет {page}/{total_pages}", reply_markup=nav_markup)


# Обработчик для перехода между страницами
@bot.callback_query_handler(func=lambda call: call.data.startswith('page_'))
def handle_page_navigation(call):
    chat_id = call.message.chat.id
    page = int(call.data.split('_')[1])
    display_user_posts(chat_id, page)

# Обработчик нажатий на кнопку удаления
@bot.callback_query_handler(func=lambda call: call.data.startswith('delpost_'))
def handle_delete_post(call):
    post_id = int(call.data.split('_')[1])
    chat_id = call.message.chat.id

    user_file_path = os.path.join(users_folder, f"{chat_id}.json")

    # Считываем данные пользователя
    with open(user_file_path, 'r', encoding='utf-8') as user_file:
        user_data = json.load(user_file)

    user_posts = user_data.get('post', [])

    # Удаляем пост ID из списка постов пользователя
    if post_id in user_posts:
        user_posts.remove(post_id)
        user_data['post'] = user_posts

        # Удаляем файл поста
        post_file_path = os.path.join(posts_folder, f"{post_id}.json")
        if os.path.exists(post_file_path):
            os.remove(post_file_path)

        # Удаляем фотографии поста
        post_data = {
            "photo": []
        }
        for photo in post_data['photo']:
            if os.path.exists(photo):
                os.remove(photo)

        # Сохраняем обновленные данные пользователя
        with open(user_file_path, 'w', encoding='utf-8') as user_file:
            json.dump(user_data, user_file)

        bot.send_message(chat_id, "Жарнама жойылды")
    else:
        bot.send_message(chat_id, "Бұл жарнама жойылып кеткен!")

# Обработчик нажатий на кнопку изменения доступности
@bot.callback_query_handler(func=lambda call: call.data.startswith('toggle_'))
def handle_toggle_availability(call):
    post_id = int(call.data.split('_')[1])
    chat_id = call.message.chat.id

    user_file_path = os.path.join(users_folder, f"{chat_id}.json")

    with open(user_file_path, 'r', encoding='utf-8') as user_file:
        user_data = json.load(user_file)

    # Проверяем количество коннектов
    if user_data.get('connect') is None:
        bot.send_message(chat_id, "Сізге қолжетімділікті өзгертуге коннектер жеткіліксіз!")
        return

    post_file_path = os.path.join(posts_folder, f"{post_id}.json")
    if os.path.exists(post_file_path):
        with open(post_file_path, 'r', encoding='utf-8') as post_file:
            post_data = json.load(post_file)

        # Изменяем доступность поста
        post_data['show'] = not post_data['show']

        # Сохраняем изменения
        with open(post_file_path, 'w', encoding='utf-8') as post_file:
            json.dump(post_data, post_file, ensure_ascii=False, indent=4)

        # Проверка видимости и обновление active.json
        if post_data['show']:
            # Создаем активированный пост
            almaty_tz = pytz.timezone('Asia/Almaty')
            time_almaty = datetime.now(almaty_tz)

            active_post_data = {
                "id": post_data['id'],
                "time": time_almaty.strftime('%Y-%m-%d %H:%M:%S'),
                "chat_id": chat_id
            }

            # Читаем или создаем active.json
            if os.path.exists(active_file_path):
                with open(active_file_path, 'r', encoding='utf-8') as active_file:
                    try:
                        active_posts = json.load(active_file)
                    except json.JSONDecodeError:
                        active_posts = []
            else:
                active_posts = []

            # Добавляем новый активный пост
            active_posts.append(active_post_data)

            # Сортируем active_posts по id в порядке убывания
            active_posts = sorted(active_posts, key=lambda x: x['id'], reverse=True)

            # Сохраняем обновленный список активных постов
            with open(active_file_path, 'w', encoding='utf-8') as active_file:
                json.dump(active_posts, active_file, ensure_ascii=False, indent=4)

        else:
            # Если post_data['show'] стал False, удаляем запись из active.json
            if os.path.exists(active_file_path):
                with open(active_file_path, 'r', encoding='utf-8') as active_file:
                    try:
                        active_posts = json.load(active_file)
                    except json.JSONDecodeError:
                        active_posts = []

                # Удаляем записи с данным post_id и chat_id
                active_posts = [post for post in active_posts if not (post['id'] == post_id and post['chat_id'] == chat_id)]

                # Сохраняем обновленный список
                with open(active_file_path, 'w', encoding='utf-8') as active_file:
                    json.dump(active_posts, active_file, ensure_ascii=False, indent=4)

        reduce_user_connect_by_one(chat_id)            
        bot.send_message(chat_id, "Қолжетімділік өзгертілді")
    else:
        bot.send_message(chat_id, f"Бұл жарнама жойылып кеткен")



# Запуск бота
bot.infinity_polling()
