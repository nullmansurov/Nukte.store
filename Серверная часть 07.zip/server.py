import os
import json
import aiofiles
import asyncio
import websockets
import ssl

posts_base_path = 'C:/Users/Administrator/Desktop/Service/files/posts/'

# Преобразуем строку в Unicode escape-последовательности
def to_unicode_escape(text):
    return text.encode('unicode_escape').decode('utf-8')

async def load_active_posts():
    posts_active_path = os.path.join(posts_base_path, 'main/active.json')
    async with aiofiles.open(posts_active_path, 'r', encoding='utf-8') as f:
        return json.loads(await f.read())

async def get_post_by_id(post_id):
    post_path = os.path.join(posts_base_path, f'{post_id}.json')
    if not os.path.exists(post_path):
        print(f"Файл не найден: {post_path}")
        return None

    async with aiofiles.open(post_path, 'r', encoding='utf-8') as f:
        return json.loads(await f.read())

async def send_image(websocket, image_path, post_id=None):
    if not os.path.exists(image_path):
        print(f"Изображение не найдено: {image_path}")
        return

    async with aiofiles.open(image_path, 'rb') as f:
        image_data = await f.read()
        encoded_image = image_data.decode('latin1')
        message = {
            "type": "image_data",
            "data": encoded_image,
            "postId": post_id,
        }
        await websocket.send(json.dumps(message))
        await websocket.recv()

async def filter_active_posts(active_posts, selected_regions, selected_tags):
    filtered_posts = []
    for post in active_posts:
        post_id = post["id"]
        post_data = await get_post_by_id(post_id)
        if post_data:
            # Фильтрация по регионам
            if selected_regions and post_data.get("where") not in selected_regions:
                continue

            # Фильтрация по тегам
            if selected_tags and not any(tag in post_data.get("tags", []) for tag in selected_tags):
                continue

            filtered_posts.append(post_data)
    return filtered_posts

async def search_and_filter_posts(selected_regions, selected_tags, search_query):
    directory_path = "C:/Users/Administrator/Desktop/Service/files/posts/"
    filtered_posts = []

    # Проходим по всем JSON-файлам в директории
    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):
            file_path = os.path.join(directory_path, filename)
            with open(file_path, 'r', encoding='utf-8') as file:
                post_data = json.load(file)

            # Если searchQuery непустой, проверяем совпадения
            if search_query:
                title = post_data.get("title", "")
                description = post_data.get("description", "")
                text_data = f"{title} {description}"
                
                if search_query.lower() not in text_data.lower():
                    continue  # Пропускаем, если совпадения нет

            # Фильтрация по регионам
            if selected_regions and post_data.get("where") not in selected_regions:
                continue

            # Фильтрация по тегам
            if selected_tags and not any(tag in post_data.get("tags", "") for tag in selected_tags):
                continue

            filtered_posts.append(post_data)

    return filtered_posts

async def echo(websocket, path):
    try:
        # Получаем данные от клиента
        regions_and_tags = await websocket.recv()
        regions_and_tags = json.loads(regions_and_tags)

        selected_regions = regions_and_tags.get("selectedRegions", [])
        selected_tags = regions_and_tags.get("selectedTags", [])
        search_query = regions_and_tags.get("searchQuery", "")

        # Проверяем, нужно ли запускать поиск или только фильтрацию
        if search_query:
            filtered_posts = await search_and_filter_posts(selected_regions, selected_tags, search_query)
        else:
            active_posts = await load_active_posts()
            filtered_posts = await filter_active_posts(active_posts, selected_regions, selected_tags)

        # Отправка отфильтрованных постов клиенту
        for post_data in filtered_posts:
            await websocket.send(json.dumps({"type": "post_data", "data": post_data}))
            await websocket.recv()  # Ожидаем подтверждение от клиента

            # Запросить изображения, если есть
            for photo in post_data.get("photo", []):
                await send_image(websocket, photo, post_id=post_data["id"])

    except websockets.exceptions.ConnectionClosed:
        print("Соединение закрыто клиентом")



ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(certfile='C:/Certbot/live/fexing.online/fullchain.pem',
                            keyfile='C:/Certbot/live/fexing.online/privkey.pem')

async def main():
    server = await websockets.serve(
        echo,
        "0.0.0.0",
        8715,
        ssl=ssl_context  # Добавляем SSL-контекст
    )
    await server.wait_closed()

asyncio.run(main())
